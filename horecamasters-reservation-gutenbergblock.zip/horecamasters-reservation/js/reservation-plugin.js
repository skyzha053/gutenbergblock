jQuery(document).ready(function($) {
    function updateSummary() {
        var summaryHtml = '';

        if ($('#step-2').hasClass('active')) {
            summaryHtml += '<h5>Samenvatting:</h5>' +
                '<p><strong>Reserveringstype:</strong> ' + $('#reservationType option:selected').text() + '</p>' +
                '<p><strong>Aantal Personen:</strong> ' + $('#numberOfGuests').val() + '</p>';
        } else if ($('#step-3').hasClass('active')) {
            summaryHtml += '<h5>Samenvatting:</h5>' +
                '<p><strong>Reserveringstype:</strong> ' + $('#reservationType option:selected').text() + '</p>' +
                '<p><strong>Aantal Personen:</strong> ' + $('#numberOfGuests').val() + '</p>' +
                '<p><strong>Datum:</strong> ' + $('#reservationDate').val() + '</p>';
        } else if ($('#step-4').hasClass('active')) {
            summaryHtml += '<h5>Samenvatting:</h5>' +
                '<p><strong>Reserveringstype:</strong> ' + $('#reservationType option:selected').text() + '</p>' +
                '<p><strong>Aantal Personen:</strong> ' + $('#numberOfGuests').val() + '</p>' +
                '<p><strong>Datum:</strong> ' + $('#reservationDate').val() + '</p>' +
                '<p><strong>Tijd:</strong> ' + $('#reservationTime option:selected').text() + '</p>';
        }

        $('#reservation-summary').html(summaryHtml);
    }

    function showOrHideSummary() {
        if ($('#step-2').hasClass('active')) {
            $('#reservation-summary').show();
        } else if ($('#step-1').hasClass('active')) {
            $('#reservation-summary').hide();
        }
    }

    $('.next-btn').click(function() {
        var nextStep = $(this).data('next-step');
        $('.step').removeClass('active');
        $('#step-' + nextStep).addClass('active');
        updateSummary();
        showOrHideSummary();
    });

    $('.prev-btn').click(function() {
        var prevStep = $(this).data('prev-step');
        $('.step').removeClass('active');
        $('#step-' + prevStep).addClass('active');
        updateSummary();
        showOrHideSummary();
    });

    // Initial update to hide summary on page load
    $('#reservation-summary').hide();

    // Initialiseer Flatpickr voor de datumpicker
    $('#reservationDatePicker').flatpickr({
        inline: true, // Zorg ervoor dat de kalender altijd zichtbaar is
        minDate: 'today', // Alleen toekomstige datums
        dateFormat: 'Y-m-d', // Formaat van de datum
        onChange: function(selectedDates, dateStr, instance) {
            $('#reservationDate').val(dateStr);
            updateSummary(); // Werk de samenvatting bij bij het wijzigen van de datum
        }
    });

    jQuery(document).ready(function($) {
        function showTooltip() {
            $('#reservation-tooltip .tooltiptext').css({
                'visibility': 'visible',
                'opacity': '1'
            });
        }
    
        // Toon de tooltip na 5 seconden
        setTimeout(showTooltip, 1000);
    });

    
    
});
