const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;


registerBlockType('reservation-plugin/reservation-form', {
    title: __('Reserveringsformulier'),
    icon: 'calendar',
    category: 'widgets',
    edit: function() {
        return wp.element.createElement(
            'div',
            { className: 'reservation-form-placeholder' },
            __('Reserveringsformulier wordt hier weergegeven.')
        );
    },
    save: function() {
        return null;
    },
});

wp.domReady(function () {
    wp.blocks.registerBlockStyle('reservation-plugin/reservation-form', {
        name: 'default',
        label: 'Standaard',
        isDefault: true,
    });
});