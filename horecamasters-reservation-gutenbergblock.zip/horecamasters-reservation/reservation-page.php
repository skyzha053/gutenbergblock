<?php
/* Template Name: Reservation Page */
get_header();

$options = get_option('reservation_plugin_options');
$logo_url = $options['logo_url'] ?? plugin_dir_url(__FILE__) . 'images/horecamasters-logo.png';
$logo_width = $options['logo_width'] ?? 100;
$logo_position = $options['logo_position'] ?? 'right';
$bg_color = $options['bg_color'] ?? '#ffffff';
$font_family = $options['font_family'] ?? 'Arial, sans-serif';
$font_size = $options['font_size'] ?? 16;
$text_content = $options['text_content'] ?? 'Welkom bij onze reserveringspagina';

?>
<div class="reservation-page" style="background-color: <?php echo esc_attr($bg_color); ?>; font-family: <?php echo esc_attr($font_family); ?>; font-size: <?php echo esc_attr($font_size); ?>px;">
    <div class="left-side">
        <h2><?php echo esc_html($text_content); ?></h2>
        <p>Voer hieronder uw gegevens in om een reservering te maken. We kijken ernaar uit u te verwelkomen!</p>
    </div>
    <div class="right-side">
        <?php echo do_shortcode('[reservation_form]'); ?>
    </div>
</div>

<!-- Voeg het HorecaMasters-logo toe -->
<div class="horecamasters-logo" style="width: <?php echo esc_attr($logo_width); ?>px; <?php echo esc_attr($logo_position); ?>: 10px;">
    <img src="<?php echo esc_url($logo_url); ?>" alt="HorecaMasters Logo" style="width: 100%; height: auto;">
</div>

<?php get_footer(); ?>
