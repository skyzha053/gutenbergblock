<?php
/*
Plugin Name: Horeca-Masters
Description: Plugin om te reserveren via Horeca-Masters.
Version: 1.1
Author: Remon ter Weele
*/

// Voeg CSS en JS toe voor de frontend
function reservation_plugin_enqueue_assets() {
    if (has_block('reservation-plugin/reservation-form')) {
        wp_enqueue_style('reservation-plugin-css', plugin_dir_url(__FILE__) . 'css/reservation-plugin.css');
        wp_enqueue_script('reservation-plugin-js', plugin_dir_url(__FILE__) . 'js/reservation-plugin.js', ['jquery'], null, true);

        wp_enqueue_style('flatpickr-css', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css');
        wp_enqueue_script('flatpickr-js', 'https://cdn.jsdelivr.net/npm/flatpickr', ['jquery'], null, true);
    }
}
add_action('wp_enqueue_scripts', 'reservation_plugin_enqueue_assets');

// Voeg blok-scripts en -styles toe voor de editor
function reservation_plugin_enqueue_block_editor_assets() {
    wp_enqueue_script(
        'reservation-plugin-block',
        plugins_url('blocks/reservation-form-block.js', __FILE__),
        ['wp-blocks', 'wp-element', 'wp-i18n'],
        filemtime(plugin_dir_path(__FILE__) . 'blocks/reservation-form-block.js')
    );

    wp_enqueue_style(
        'reservation-plugin-block-editor',
        plugins_url('css/reservation-plugin.css', __FILE__),
        [],
        filemtime(plugin_dir_path(__FILE__) . 'css/reservation-plugin.css')
    );
}
add_action('enqueue_block_editor_assets', 'reservation_plugin_enqueue_block_editor_assets');

// Registreer de shortcode [reservation_form]
function reservation_plugin_register_shortcode() {
    add_shortcode('reservation_form', 'reservation_plugin_form_content');
}
add_action('init', 'reservation_plugin_register_shortcode');

// Functie voor formulier-inhoud
function reservation_plugin_form_content() {
    ob_start();
    ?>
    <div class="reservation-form">
        <form id="reservation-form" method="post">
            <div id="reservation-multistep-form">
                <div id="reservation-summary"></div>
                <div class="step active" id="step-1">
                    <label for="reservationType">Reserveringstype:</label>
                    <select id="reservationType" name="reservationType" required>
                        <option value="">Selecteer...</option>
                        <option value="diner">Diner</option>
                        <option value="lunch">Lunch</option>
                        <option value="ontbijt">Ontbijt</option>
                    </select><br>
                    <label for="numberOfGuests">Aantal Personen:</label>
                    <input type="number" id="numberOfGuests" name="numberOfGuests" min="1" required><br>
                    <input type="hidden" id="companyName" name="companyName" value="<?php echo esc_attr(get_option('reservation_plugin_options')['company_name'] ?? ''); ?>">
                    <button type="button" class="next-btn" data-next-step="2">Volgende</button>
                </div>
                <div class="step" id="step-2">
                    <h5>Kies een dag</h5>
                    <div id="reservationDatePicker" class="datepicker"></div>
                    <input type="hidden" id="reservationDate" name="reservationDate" required>
                    <button type="button" class="prev-btn" data-prev-step="1">Vorige</button>
                    <button type="button" class="next-btn" data-next-step="3">Volgende</button>
                </div>
                <div class="step" id="step-3">
                    <h5>Kies een tijd</h5>
                    <label for="reservationTime">Tijd:</label>
                    <select id="reservationTime" name="reservationTime" required>
                        <?php for ($i = 0; $i < 24; $i++): ?>
                            <?php for ($j = 0; $j < 60; $j += 15): ?>
                                <option value="<?php printf('%02d:%02d', $i, $j); ?>"><?php printf('%02d:%02d', $i, $j); ?></option>
                            <?php endfor; ?>
                        <?php endfor; ?>
                    </select><br>
                    <button type="button" class="prev-btn" data-prev-step="2">Vorige</button>
                    <button type="button" class="next-btn" data-next-step="4">Volgende</button>
                </div>
                <div class="step" id="step-4">
                    <h5>Vul uw contactgegevens in</h5>
                    <label for="firstName">Voornaam:</label>
                    <input type="text" id="firstName" name="firstName" required><br>
                    <label for="lastName">Achternaam:</label>
                    <input type="text" id="lastName" name="lastName" required><br>
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required><br>
                    <label for="phoneNumber">Telefoonnummer:</label>
                    <input type="text" id="phoneNumber" name="phoneNumber" required><br>
                    <label for="specialRequests">Speciale Verzoeken:</label>
                    <textarea id="specialRequests" name="specialRequests"></textarea><br>
                    <button type="button" class="prev-btn" data-prev-step="3">Vorige</button>
                    <button type="submit" name="submit_reservation" id="submitReservation">Reservering Verzenden</button>
                </div>
            </div>
        </form>
    </div>
    <?php
    return ob_get_clean();
}

// Verwerk formuliergegevens en verstuur naar API
function reservation_plugin_handle_form() {
    if (isset($_POST['submit_reservation'])) {
        $api_url = 'http://localhost:8080/reservations/createreservationpublic';
        $data = array(
            'customer' => array(
                'firstName' => sanitize_text_field($_POST['firstName']),
                'lastName' => sanitize_text_field($_POST['lastName']),
                'email' => sanitize_email($_POST['email']),
                'phoneNumber' => sanitize_text_field($_POST['phoneNumber']),
            ),
            'companyName' => sanitize_text_field($_POST['companyName']),
            'reservationDate' => sanitize_text_field($_POST['reservationDate']),
            'reservationTime' => sanitize_text_field($_POST['reservationTime']),
            'numberOfGuests' => intval($_POST['numberOfGuests']),
            'specialRequests' => sanitize_textarea_field($_POST['specialRequests']),
        );

        $response = wp_remote_post($api_url, array(
            'body'    => json_encode($data),
            'headers' => array('Content-Type' => 'application/json'),
        ));

        if (is_wp_error($response)) {
            return 'Er is een fout opgetreden bij het verzenden van de reservering.';
        }

        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code == 201) {
            $redirect_page_id = get_option('reservation_plugin_options')['redirect_page'] ?? 0;
            $redirect_url = get_permalink($redirect_page_id);
            wp_redirect($redirect_url);
            exit;
        } else {
            return 'Er is een fout opgetreden bij het aanmaken van de reservering.';
        }
    }
}

// Voeg instellingenpagina toe aan het WordPress dashboard
function reservation_plugin_add_admin_menu() {
    add_options_page(
        'HorecaMasters',
        'HorecaMasters',
        'manage_options',
        'reservation_plugin_settings',
        'reservation_plugin_settings_page'
    );
}
add_action('admin_menu', 'reservation_plugin_add_admin_menu');

// Instellingenpagina
function reservation_plugin_settings_page() {
    ?>
    <div class="wrap">
        <h1>HorecaMasters</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('reservation_plugin_options_group');
            do_settings_sections('reservation_plugin_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Initialiseer instellingen
function reservation_plugin_settings_init() {
    register_setting('reservation_plugin_options_group', 'reservation_plugin_options');

    add_settings_section(
        'reservation_plugin_settings_section',
        'Algemene Instellingen',
        null,
        'reservation_plugin_settings'
    );

    add_settings_field(
        'reservation_plugin_company_name',
        'Bedrijfsnaam',
        function() {
            $options = get_option('reservation_plugin_options');
            ?>
            <input type="text" name="reservation_plugin_options[company_name]" value="<?php echo esc_attr($options['company_name'] ?? ''); ?>">
            <?php
        },
        'reservation_plugin_settings',
        'reservation_plugin_settings_section'
    );

    add_settings_field(
        'reservation_plugin_redirect_page',
        'Doorverwijs-pagina na Reservering',
        function() {
            $options = get_option('reservation_plugin_options');
            $pages = get_pages();
            ?>
            <select name="reservation_plugin_options[redirect_page]">
                <option value="0">Selecteer een pagina</option>
                <?php foreach ($pages as $page): ?>
                    <option value="<?php echo esc_attr($page->ID); ?>" <?php selected($page->ID, $options['redirect_page'] ?? 0); ?>><?php echo esc_html($page->post_title); ?></option>
                <?php endforeach; ?>
            </select>
            <?php
        },
        'reservation_plugin_settings',
        'reservation_plugin_settings_section'
    );
}
add_action('admin_init', 'reservation_plugin_settings_init');

// Registreer het blok
function reservation_plugin_register_block() {
    register_block_type('reservation-plugin/reservation-form', array(
        'render_callback' => 'reservation_plugin_render_form',
        'supports' => array(
            'html' => false,
        ),
    ));
}
add_action('init', 'reservation_plugin_register_block');

// Render-functie voor het blok
function reservation_plugin_render_form($attributes, $content) {
    ob_start();
    ?>
    <div class="wp-block-reservation-plugin-reservation-form">
        <?php echo reservation_plugin_form_content(); ?>
    </div>
    <?php
    $form_content = ob_get_clean();
    $form_handler = reservation_plugin_handle_form();
    return $form_content . (is_string($form_handler) ? '<p>' . esc_html($form_handler) . '</p>' : '');
}
